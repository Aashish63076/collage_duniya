from collections import Counter
from django.http import HttpResponse

from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
import os

from django.contrib import messages

import pandas as pd

# Create your views here.


#dict ={}
def index(request):
    return  render(request, 'index.html',)

def summary(request):
    data=pd.read_csv("C:/Users/akpan/Desktop/Artificial_intelligence/college_duniya/media/12feb.csv") 
    
    header = data.head().to_html() 
    tailer = data.tail().to_html() 
    data = data.to_html()  
    
    return render(request, 'summary.html' ,{'data':data,'header':header, 'tailer':tailer})
    



def results(request):
    # prepare the visualization
                                #12
    """message = 'I found ' + str(rows) + ' rows and ' + str(columns) + ' columns. Missing data: ' + str(missing_values)
    messages.warning(request, message)"""
    my_file = pd.read_csv("C:/Users/akpan/Desktop/Artificial_intelligence/college_duniya/media/12feb.csv", sep='[:;,|_]', engine='python')

    data = pd.DataFrame(data=my_file, index=None)
    item = list(data['item'])
    open= list(data['open'])
    heigh = list(data['high'])
    low = list(data['low'])
    fluctuation = list(round(data['high'] - data['low']))  


    

   

    context = {
        'item': item,
        'open': open,
        'heigh': heigh,
        'low' : low ,
        'fluctuation' : fluctuation,
        
    }

    return render(request, 'results.html', context)
    
